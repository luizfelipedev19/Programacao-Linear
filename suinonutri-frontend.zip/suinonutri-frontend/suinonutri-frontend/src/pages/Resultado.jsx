import { useEffect, useMemo, useState } from 'react'
import { Shell } from '../components/Shell'
import { buscarModelo, buscarProblema, listarResultados, getUsuario } from '../services/api'
import '../restricoes.css'

const num = (v, casas = 2) => v.toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas })
const brl = (v) => 'R$ ' + num(v)
const valorComUnidade = (v, unidade) => (unidade === 'fração' ? `${num(v * 100)} %` : `${num(v)} ${unidade ?? ''}`.trim())

export function Resultado({ id, aoNavegar, aoSair }) {
  const [problema, setProblema] = useState(null)
  const [res, setRes] = useState(undefined) // undefined = carregando | null = sem cálculo
  const [modelo, setModelo] = useState(null)
  const [erro, setErro] = useState('')
  const [quantidade, setQuantidade] = useState('100')

  useEffect(() => {
    Promise.all([buscarProblema(id), listarResultados(id), buscarModelo(id)])
      .then(([p, r, m]) => { setProblema(p); setRes(r[0] ?? null); setModelo(m) })
      .catch((e) => setErro(e instanceof Error ? e.message : 'Não foi possível carregar o resultado.'))
  }, [id])

  const kg = Math.max(0, Number(String(quantidade).replace(',', '.')) || 0)
  const preco = new Map(modelo?.variaveis.map((v) => [v.nome, v.coeficiente_objetivo]))
  const unidade = new Map(modelo?.restricoes.map((r) => [r.nome, r.unidade]))

  const otimo = res?.status === 'OTIMO' && res.valor_objetivo != null
  const itens = (res?.variaveis ?? []).filter((v) => v.valor > 1e-6).sort((a, b) => b.valor - a.valor)

  // junta "mínima" e "máxima" do mesmo item em uma única linha de conferência
  const conferencia = useMemo(() => {
    if (!res) return []
    const mapa = new Map()
    for (const r of res.restricoes) {
      const un = unidade.get(r.nome)
      if (un === 'fração' && !r.nome.startsWith('Adicional')) continue // limites de ingrediente e soma não entram
      const base = r.nome.replace(/ (mínimo|mínima|máximo|máxima)$/, '')
      const linha = mapa.get(base) ?? { nome: base, un, obtido: r.valor_calculado, ok: true, min: null, max: null, igual: null }
      if (r.sinal === '>=') linha.min = r.valor_restricao
      else if (r.sinal === '<=') linha.max = r.valor_restricao
      else linha.igual = r.valor_restricao
      linha.ok = linha.ok && r.atendida
      mapa.set(base, linha)
    }
    return [...mapa.values()]
  }, [res, modelo])

  const exigido = (l) => {
    const partes = []
    if (l.min != null) partes.push(`mín. ${valorComUnidade(l.min, l.un)}`)
    if (l.max != null) partes.push(`máx. ${valorComUnidade(l.max, l.un)}`)
    if (l.igual != null) partes.push(`exato ${valorComUnidade(l.igual, l.un)}`)
    return partes.join(' • ')
  }

  return (
    <Shell ativo="dashboard" aoNavegar={aoNavegar} aoSair={aoSair}
      extra={<button className="voltar" onClick={() => aoNavegar('dashboard')}>← Início</button>}>
      <h1>Resultado</h1>
      <p className="sub">{problema ? problema.nome : '…'}</p>

      <div className="so-impressao">
        <strong>SuínoNutri — Receita da ração</strong>
        <span>{problema?.nome} • {getUsuario()?.nome} • {new Date().toLocaleDateString('pt-BR')}</span>
      </div>

      {erro && <div className="erro">{erro}</div>}
      {res === undefined && !erro && <div className="vazio">Carregando…</div>}
      {res === null && <div className="aviso">Esta formulação ainda não foi calculada.</div>}

      {res && !otimo && (
        <div className="erro">
          {res.status === 'INVIAVEL'
            ? 'Não existe uma ração que atenda a todas as exigências com esses ingredientes. Tente liberar mais ingredientes, aumentar os limites máximos, ampliar a faixa das exigências ou remover alguma restrição adicional.'
            : res.status === 'ILIMITADO'
              ? 'O cálculo não encontrou um limite para o custo. Revise os dados informados.'
              : 'Não foi possível calcular essa formulação. Revise os dados e tente de novo.'}
        </div>
      )}

      {otimo && res && (
        <>
          <section className="destaque duplo">
            <div>
              <p>Custo por kg de ração</p>
              <strong>{brl(res.valor_objetivo)}</strong>
            </div>
            <div>
              <p>Custo total para {num(kg, kg % 1 ? 2 : 0)} kg</p>
              <strong>{brl(res.valor_objetivo * kg)}</strong>
            </div>
          </section>

          <section className="qtd-bloco no-print">
            <label htmlFor="qtd">Quanto de ração você quer produzir?</label>
            <div className="qtd-linha">
              <div className="qtd-campo">
                <input id="qtd" inputMode="decimal" value={quantidade} onChange={(e) => setQuantidade(e.target.value)} />
                <span>kg</span>
              </div>
              {[100, 500, 1000].map((v) => (
                <button key={v} type="button" className={`chip ${kg === v ? 'ativo' : ''}`} onClick={() => setQuantidade(String(v))}>{v} kg</button>
              ))}
            </div>
          </section>

          <section className="secao">
            <h2>Misture assim</h2>
            <p className="dica">Para produzir <strong>{num(kg, kg % 1 ? 2 : 0)} kg</strong> de ração, use as quantidades abaixo.</p>
            <div className="receita">
              {itens.map((v) => (
                <div key={v.id_variavel} className="item-receita">
                  <span className="item-nome">{v.nome}</span>
                  <span className="item-kg">{num(v.valor * kg)} kg</span>
                  <div className="item-barra"><div style={{ width: `${Math.max(2, v.valor * 100)}%` }} /></div>
                  <span className="item-nota">{num(v.valor * 100)}% da ração • {brl(v.valor * kg * (preco.get(v.nome) ?? 0))}</span>
                </div>
              ))}
            </div>
            <div className="receita-total">
              <span>Total da mistura</span>
              <strong>{num(kg, kg % 1 ? 2 : 0)} kg</strong>
            </div>
          </section>

          <details className="secao conferencia" open>
            <summary>Conferir as exigências</summary>
            <ul className="conf-lista">
              {conferencia.map((l) => (
                <li key={l.nome} className={l.ok ? 'ok' : 'falha'}>
                  <span className="conf-icone">{l.ok ? '✓' : '✗'}</span>
                  <span><strong>{l.nome}</strong>: obtido {valorComUnidade(l.obtido, l.un)} <small>(exigido {exigido(l)})</small></span>
                </li>
              ))}
            </ul>
          </details>

          <div className="acoes-resultado no-print">
            <button className="btn-sec" onClick={() => window.print()}>Imprimir receita</button>
          </div>
        </>
      )}

      <button className="btn-nova no-print" onClick={() => aoNavegar('nova')}>
        <span style={{ fontSize: 38, lineHeight: 1, fontWeight: 300 }}>+</span> Nova Otimização
      </button>
    </Shell>
  )
}
